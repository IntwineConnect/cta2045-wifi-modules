/**
 *MCI_Common.h
 *global declarations for MCI messages
 */

extern unsigned char TimeSyncMsg[8];
extern unsigned char QueryOpState[8];


extern unsigned char  EndShedCommand[8];
extern unsigned char     ShedCommand[8];
// Set Critical Peak Event
extern unsigned char      CPPCommand[8];
// Set Present Relative Price
extern unsigned char PresentRelPrice[8];
// Outside Comm Connection Status, Found / Good Connection
extern unsigned char OutsideCommGood[8];
// Outside Comm Connection Status, No / Lost Connection
extern unsigned char OutsideCommLost[8];

//-----------------------------------------------------------------------------
// MCI Intermediate DR Application. Message Type = 0x08, 0x02
//--------------------------------------------

extern unsigned char  SetEnergyPrice[13];



#define RX_BUF_SIZE 300
#define TX_MSG_SIZE 10

extern unsigned char AppAckMsg[RX_BUF_SIZE];


