/**
 *MCI_Common.c
 * global definitions for MCI messages
 */

#include MCI_Common.h

unsigned char TimeSyncMsg[8] = { 0x08, 0x01, 0x00, 0x02, 0x16, 0x00, 0x00, 0x00};
unsigned char QueryOpState[8] = { 0x08, 0x01, 0x00, 0x02, 0x12, 0x00, 0x00, 0x00};

unsigned char AppAckMsg[RX_BUF_SIZE] = { 0x08, 0x01, 0x00, 0x02, 0x03, 0x00, 0x00, 0x00};

//-----------------------------------------------------------------------------
// MCI Basic DR command. Message Type = 0x08, 0x01
//---------------------------------
// Refer to "Modular Communication Interface Specification for Demand Response"
// Bytes 1,2 are Message Type
// Bytes 3,4 are length msb, lsb.
// Bytes 5,6 are Opcode1, Opcode2
// Bytes 7,8 are checksum, calculated by MCISend()

unsigned char  EndShedCommand[] = { 0x08, 0x01, 0x00, 0x02, 0x02, 0x00, 0xff, 0xff };
unsigned char  ShedCommand[] = { 0x08, 0x01, 0x00, 0x02, 0x01, 0x00, 0xff, 0xff };
// Set Critical Peak Event
unsigned char  CPPCommand[] = { 0x08, 0x01, 0x00, 0x02, 0x0A, 0x00, 0xff, 0xff };
// Set Present Relative Price
unsigned char PresentRelPrice[] = { 0x08, 0x01, 0x00, 0x02, 0x07, 0x01, 0xff, 0xff };
// Outside Comm Connection Status, Found / Good Connection
unsigned char OutsideCommGood[] = { 0x08, 0x01, 0x00, 0x02, 0x0E, 0x01, 0xff, 0xff };
// Outside Comm Connection Status, No / Lost Connection
unsigned char OutsideCommLost[] = { 0x08, 0x01, 0x00, 0x02, 0x0E, 0x00, 0xff, 0xff };

//-----------------------------------------------------------------------------
// MCI Intermediate DR Application. Message Type = 0x08, 0x02
//--------------------------------------------

// SetEnergyPrice
// Bytes 7,8 are Current Price
// Bytes 9,10 are Currency code = 840 for US dollars (0x348)
// Byte 11 is digits after decimal place, currently fixed at 2 (cents)
unsigned char  SetEnergyPrice[] = { 0x08, 0x02, 0x00, 0x07, 0x03, 0x00, 0x00, 0x00, 0x03, 0x48, 0x02, 0xff, 0xff };
